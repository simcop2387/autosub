function outSpeech = PostProc(Synth)
% function outSpeech = PostProc(Synth)
outSpeech=Synth; % For simplicity